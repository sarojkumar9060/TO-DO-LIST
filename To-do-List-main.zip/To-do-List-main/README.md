﻿# To-do-List
An application is wherein user keeps track of all the tasks a user gotta do and it's completing status.


